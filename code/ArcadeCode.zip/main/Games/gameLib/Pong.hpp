#pragma once

class Pong{
    public:
        Pong();

    private:
        
};