#define TOP_LEFT_PIN 5
#define TOP_RIGHT_PIN 4
#define BOT_LEFT_PIN 3
#define BOT_RIGHT_PIN 2

#define BUTTON_1_PIN 6
#define BUTTON_2_PIN 7
#define BUTTON_3_PIN 8

#define JOYSTICK_1_X_PIN A0
#define JOYSTICK_1_Y_PIN A1
#define JOYSTICK_1_D_PIN 9
